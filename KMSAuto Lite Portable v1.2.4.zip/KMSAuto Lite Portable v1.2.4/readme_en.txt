			KMSAuto Lite Portable by Ratiborus, 
 				  MSFree Inc. 

          			System requirements: 
                          ���������������������������������
 Windows XP, Windows Vista, 7, Windows 8, 8.1, 10, Server 2008, 2008 R2, 2012, 
 2012 R2, Office 2010/2013/2016 VL editions. 
 **** The program does NOT require any version .NET Framework. **** 

 			         Description: 
                           ���������������������������������
 KMSAuto Lite - KMS-activator for the operating systems 
 Windows VL editions: Vista, 7, 8, 8.1, 10, Server 2008, 2008 R2, 2012, 
 2012 R2 and Office 2010, 2013, 2016. Also you can activate Office 2010 VL 
 on Windows XP. 
 The switches provide access to the installation GVLK keys and configure the task scheduler. 

  		    Advanced startup options of the program (keys): 
                          ��������������������������������� 
 /win=act	- Run the program in stealth mode, activate Windows 
 		  and exit the program. 
 /ofs=act	- Run the program in stealth mode, activate Office 
 		  and exit the program. 
 /wingvlk=inst	- Run the program in stealth mode, install the Windows key 
 		  and exit the program. 
 /ofsgvlk=inst	- Run the program in stealth mode, install the Office keys 
 		  and exit the program. 
 /ofs=conv	- To run the program in stealth mode, convert Office 2013 RETAIL 
 		  in VL and exit the program. Will be converted only non-activated products. 
 /sched=win	- Create a task scheduler to activate Windows every 25 days. 
 /sched=ofs	- Create a task scheduler to activate Office every 25 days. 

 *** Keys installed forcibly, parameters can be applied all together. 
 *** Convert RETAIL -> VL possible only for non-activated office products. 

   On the "Settings" tab, you can specify the external address of the KMS Service. Built-in 
 program service will not run when activated . If activation fails 0xc004f074, 
 make sure that your firewall does not prohibit a connection with your KMS-Service. 
 If you create a task scheduler for reactivation (in the program for this purpose is 
 special tab), the program can move wherever you want, you can even completely 
 remove it, it is not necessary to reactivate. 

               			Installing KMS-Service: 
                          ���������������������������������
   On the "Settings" tab you can install into the system KMS-Service, Windows 7-8 
 can be activated their own of it, if configured, 
 at the address 127.0.0.2:port, and on your network adress can be activated any systems and offices. 
 Installed server does not conflict with the task scheduler or manual activation, 
 if used buttons "Activate Windows" and "Activate Office". If your system is 8.1, on the process of 
 activation will be installed a special driver, which is removed at the end of activation. 
 For this configuration must be installed "== Integrated KMS-Service ==". 
 You can also configure the activation of an external server, upon activation by pressing the buttons at 
 Main program window your system settings are not changed, they will be restored immediately 
 after activation. 
 Using two buttons at the bottom window "Settings", you can view logfile of a running server. 

   			    "At me nothing activated !!!!" 
                          ���������������������������������
 Perhaps you have a non-VL product, which is not intended to activate using KMS-Service 
 (Windows 7 Ultimate this program does NOT ACTIVATE), or your antivirus blocks the activation.

	 ����������������������������������������������������������������� 
                                				 Ratiborus 


Changes in versions: 
v1.2.4
�-Changes in program for compatibility with antivirus software.
 -Fixed the nonworking "Install KMS-Service" button.

v1.2.2
 -Added Keys for Windows 10 and Office 2016.

v1.2.1
 -Added interface translation into Ukrainian.
 -Added program for Windows 10 "Show or hide updates"

v1.2.0
 -Re-compiled KMS Service.
 -Added Keys for Windows 10 and Office 2016.

v1.1.9
 -Added switch "Random IP address".


v1.1.8 
 -Added ability to convert Office 2010 ProPlus on Windows 7-10. 

v1.1.7 
 -In program now is built utility to save and restore activation.

v1.1.6 
-Added interface translation into Vietnamese.

v1.1.5 
 -Added function correcting work MS Excel. 
 -KMS Log Analyzer works with the original logfile KMS-Service. 
 -Small changes in the program interface.

v1.1.4 
 -Can launch only one copy of the program. 
 -Fixed a bug at which key win=act was not working on Windows 7

v1.1.3 
 -Changes in the interface. 
 -Added function "Delete state invalid system"

v1.1.2
 -Changes in the interface. 

v1.1.1 
 -Changes in the interface. 
 -Added new functions. 
 -Fixed a bug with the forced installation of the keys. 
 -New version of the KMS-Service, fixed output HWid.

 v1.1.0 
 -Changes in the interface. 
 -Added new functions.

 v1.0.8 
 -Changes in the interface. 
 -Added English interface.

 v1.0.7 
 -Changes in the interface. 
 -The program now remembers the position of her window on the screen. 
 -Added command line switches. 
 -Added ability to set up a local KMS-Service with the specified parameters. 

 v1.0.6 
 -Changes in the interface. 
 -Added new command line switch. 
 -Changed algorithm some features of the program. 

 v1.0.5.1 
 -Changes in the interface. 
 -Added ability to set your address KMS-Service and any port. 
 -Added ability to convert Office 2013 products on Windows 7-10. 

 v1.0.4 
 -Changes in the interface. 
 -Added ability to run the program with the keys. 
 -Added ability to create a task scheduler for reactivation Windows and 
 Office every 25 days. This function does not work on Windows XP. 

 v1.0.3 
 -Changes in the interface. 
 -Added ability to install GVLK keys forcibly. 

 v1.0.2 
 -Fixed error with installation keys. 

 v1.0.1 
 -Changes in the interface. 
 -Added ability to install GVLK keys. 

 v1.0.0 
 -First version, test. 
 [/more] 



